const { getrobloxid} = require('./rbxaccounthandler.js');

getrobloxid("werdvon124", {}).then((moduleresponse) => {
	console.log(moduleresponse)
})