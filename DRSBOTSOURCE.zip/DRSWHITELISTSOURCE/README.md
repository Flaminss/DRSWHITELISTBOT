# ROBLOX Management bot for PPCC

This bot is used to communicate across the roblox and noblox API for access to group administration features such as ranking and group shouts.

A verification system is also being developed for the bot to allow easier access to ranking, syncing roles and ROBLOX usernames to discord nicknames.

If you plan on using this bot for your own use, you must make a config.json file containing the following:

```json
{
    "token": "YOURTOKEN",
    "clientID": "BOTCLIENTID",
    "status": {
        "type": "WATCHING",
        "text": "STATUS",
        "online": "online"
    }
}
```
https://discord.gg/ua6y5kjeHh

Bot Developer: 𝓂𝑜𝒹#6969
